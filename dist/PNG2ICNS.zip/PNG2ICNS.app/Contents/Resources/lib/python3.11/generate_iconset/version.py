__version_info__ = (1, 2, 0)
__version__ = ".".join(map(str, __version_info__))
